const topics = {
    // Historia
    "Revolución Industrial": "Periodo de transición a nuevas manufacturas en Europa y EE.UU. entre 1760 y 1840.",
    "Imperialismo": "Política de expansión de un país mediante la conquista o control de territorios ajenos.",
    // ... (agrega los demás conceptos aquí)
    "Cocina": "Arte de preparar y cocinar alimentos.",
    // Colegio Villahermosa
    "Colegio Villahermosa": "Institución educativa dedicada a la formación integral de los estudiantes.",
};

const searchInput = document.getElementById("search");
const suggestions = document.getElementById("suggestions");
const description = document.getElementById("description");

searchInput.addEventListener("input", function() {
    const input = this.value.toLowerCase();
    suggestions.innerHTML = '';
    description.style.display = 'none';

    if (input) {
        const filteredTopics = Object.keys(topics).filter(topic => 
            topic.toLowerCase().includes(input)
        );

        filteredTopics.forEach(topic => {
            const suggestion = document.createElement("div");
            suggestion.className = "suggestion";
            suggestion.innerText = topic;
            suggestion.onclick = function() {
                searchInput.value = topic;
                showDescription(topic);
                suggestions.innerHTML = '';
                suggestions.style.display = 'none';
            };
            suggestions.appendChild(suggestion);
        });
        suggestions.style.display = filteredTopics.length ? 'block' : 'none';
    } else {
        suggestions.style.display = 'none';
    }
});

searchInput.addEventListener("keydown", function(event) {
    if (event.key === "Tab" && suggestions.innerHTML !== '') {
        event.preventDefault();
        const firstSuggestion = suggestions.firstChild;
        if (firstSuggestion) {
            searchInput.value = firstSuggestion.innerText;
            showDescription(firstSuggestion.innerText);
            suggestions.innerHTML = '';
            suggestions.style.display = 'none';
        }
    }
});

function showDescription(topic) {
    description.innerText = topics[topic];
    description.style.display = 'block';
}
